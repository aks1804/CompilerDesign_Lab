
#include<stdio.h>
intmain(){
intn,i,sum=0;
printf("Enterapositiveinteger:");
scanf("%d",&n);

for(i=1;i<=n;++i){
sum+=i;
}
printf("Sum=%d",sum);
return0;
}
